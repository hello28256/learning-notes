#!/bin/bash

# 学习笔记管理系统 - 阿里云ECS部署脚本
# 使用方法: ./deploy.sh [install|start|stop|restart|status|logs|update|clean]

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 配置
COMPOSE_FILE="docker-compose.ecs.yml"
PROJECT_NAME="learning-notes"

# 打印带颜色的消息
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查Docker环境
check_docker() {
    print_info "检查Docker环境..."

    if ! command -v docker &> /dev/null; then
        print_info "正在安装Docker..."
        if command -v apt &> /dev/null; then
            apt update && apt install -y docker.io
        elif command -v yum &> /dev/null; then
            yum install -y docker-ce docker-ce-cli containerd.io
        else
            print_error "无法自动安装Docker，请手动安装"
            exit 1
        fi
        systemctl enable docker
        systemctl start docker
    fi

    if ! docker compose version &> /dev/null; then
        print_info "正在安装Docker Compose..."
        curl -L "https://github.com/docker/compose/releases/download/v2.23.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
        chmod +x /usr/local/bin/docker-compose
        ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose
    fi

    print_success "Docker环境检查通过"
}

# 安装项目
install() {
    print_info "开始安装项目..."
    
    check_docker
    
    # 创建必要的目录
    mkdir -p uploads database
    
    # 检查schema.sql是否存在
    if [ ! -f "database/schema.sql" ]; then
        print_info "创建数据库初始化脚本..."
        cat > database/schema.sql << 'EOF'
CREATE DATABASE IF NOT EXISTS learning_notes CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE learning_notes;

CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    password VARCHAR(100) NOT NULL COMMENT '密码',
    email VARCHAR(100) COMMENT '邮箱',
    avatar VARCHAR(500) COMMENT '头像URL',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

CREATE TABLE IF NOT EXISTS notes (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL COMMENT '标题',
    content LONGTEXT COMMENT '内容',
    category VARCHAR(50) COMMENT '分类',
    tags VARCHAR(500) COMMENT '标签，逗号分隔',
    is_public BOOLEAN DEFAULT TRUE COMMENT '是否公开',
    view_count INT DEFAULT 0 COMMENT '浏览次数',
    user_id BIGINT NOT NULL COMMENT '用户ID',
    file_path VARCHAR(500) COMMENT '文件路径',
    file_type VARCHAR(20) COMMENT '文件类型',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_tags (tags),
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='笔记表';
EOF
    fi
    
    print_success "安装完成"
    print_info "请运行: ./deploy.sh start 启动服务"
}

# 启动服务
start() {
    print_info "启动服务..."
    
    check_docker
    
    if [ ! -f "$COMPOSE_FILE" ]; then
        print_error "未找到 $COMPOSE_FILE 文件"
        exit 1
    fi
    
    # 创建上传目录
    mkdir -p uploads
    
    print_info "正在构建并启动容器..."
    docker compose -f $COMPOSE_FILE up --build -d
    
    if [ $? -eq 0 ]; then
        print_success "服务启动成功!"
        echo ""
        print_info "访问地址:"
        IP=$(curl -s ifconfig.me || curl -s ipinfo.io/ip || echo "localhost")
        echo "  前端: http://$IP"
        echo "  后端: http://$IP:8080/api/notes"
        echo ""
        print_info "查看日志: ./deploy.sh logs"
        print_info "停止服务: ./deploy.sh stop"
    else
        print_error "服务启动失败"
        exit 1
    fi
}

# 停止服务
stop() {
    print_info "停止服务..."
    docker compose -f $COMPOSE_FILE down
    print_success "服务已停止"
}

# 重启服务
restart() {
    print_info "重启服务..."
    stop
    start
}

# 查看状态
status() {
    print_info "服务状态:"
    docker compose -f $COMPOSE_FILE ps
}

# 查看日志
logs() {
    if [ -z "$2" ]; then
        docker compose -f $COMPOSE_FILE logs -f --tail=100
    else
        docker compose -f $COMPOSE_FILE logs -f --tail=100 "$2"
    fi
}

# 更新项目
update() {
    print_info "更新项目..."
    stop
    
    # 备份数据
    BACKUP_DIR="backup_$(date +%Y%m%d_%H%M%S)"
    mkdir -p $BACKUP_DIR
    
    # 备份上传文件
    if [ -d "uploads" ]; then
        cp -r uploads $BACKUP_DIR/
        print_info "上传文件已备份到 $BACKUP_DIR/uploads"
    fi
    
    # 重新构建并启动
    docker compose -f $COMPOSE_FILE up --build -d
    
    print_success "更新完成"
}

# 清理数据（谨慎使用）
clean() {
    print_warning "警告: 这将删除所有数据，包括数据库和上传的文件!"
    read -p "确定要继续吗? (yes/no): " confirm
    
    if [ "$confirm" = "yes" ]; then
        print_info "正在清理数据..."
        docker compose -f $COMPOSE_FILE down -v
        rm -rf uploads/*
        print_success "数据已清理"
    else
        print_info "操作已取消"
    fi
}

# 主函数
main() {
    case "${1:-start}" in
        install)
            install
            ;;
        start)
            start
            ;;
        stop)
            stop
            ;;
        restart)
            restart
            ;;
        status)
            status
            ;;
        logs)
            logs "$@"
            ;;
        update)
            update
            ;;
        clean)
            clean
            ;;
        *)
            echo "使用方法: $0 [install|start|stop|restart|status|logs|update|clean]"
            echo ""
            echo "命令说明:"
            echo "  install  - 首次安装，初始化环境"
            echo "  start    - 启动服务（默认）"
            echo "  stop     - 停止服务"
            echo "  restart  - 重启服务"
            echo "  status   - 查看服务状态"
            echo "  logs     - 查看日志"
            echo "  update   - 更新项目（会重新构建）"
            echo "  clean    - 清理所有数据（谨慎使用）"
            exit 1
            ;;
    esac
}

main "$@"
